=====================================
  GIGAPARSEC
  by GRANDPAPA.NET
  Version 1.0
=====================================

HOW TO PLAY:
------------
Double-click "Play Gigaparsec.bat" to start the game.

Or open "index.html" in any web browser (Chrome, Firefox, Edge).


CONTROLS:
---------
MOUSE           - Move your ship (left half of screen)
RIGHT CLICK     - Fire lasers
SPACE           - Start game / Restart


OBJECTIVE:
----------
A side-scrolling space shooter inspired by the classic TI-99 Parsec!
Pilot your spacecraft through waves of enemy fighters, dodge
asteroids, and collect power-ups to survive.

Destroy enemies to score points and advance through levels.
Don't let enemies or asteroids hit your ship!


FEATURES:
---------
- 3 enemy types with different attack patterns
- Destructible asteroids
- Power-ups (weapon upgrades + extra lives)
- Progressive difficulty
- Retro CRT visual effects


CREDITS:
--------
Game by GRANDPAPA.NET
Free to download and share!

Visit: https://grandpapa.net

=====================================
  GAME OVER? NEVER.
=====================================
