=====================================
  SPACE JUNK BLASTER
  by GRANDPAPA.NET
  Version 1.0
=====================================

HOW TO PLAY:
------------
Double-click "Play SpaceJunkBlaster.bat" to start the game.

Or open "index.html" in any web browser (Chrome, Firefox, Edge).


CONTROLS:
---------
MOUSE MOVEMENT  - Aim your satellite
LEFT CLICK      - Fire plasma torch
RIGHT CLICK     - Thrust forward
WASD/ARROWS     - Backup movement controls
1-4 KEYS        - Select player
E KEY           - Edit player name
R KEY           - Reset all scores & players


OBJECTIVE:
----------
You are a space janitor! Use your plasma torch to melt orbital
debris before it collides with your satellite. Watch out for
asteroids - some have aliens hiding on them!

Don't get too close to Earth or you'll burn up in the atmosphere!


GAMEPAD SUPPORT:
----------------
USB controllers are supported:
- Left stick: Aim
- Right stick: Move
- A/RB/RT: Fire
- B/LB/LT: Thrust
- D-pad: Movement


CREDITS:
--------
Game by GRANDPAPA.NET
Free to download and share!

Visit: https://grandpapa.net

=====================================
  GAME OVER? NEVER.
=====================================
